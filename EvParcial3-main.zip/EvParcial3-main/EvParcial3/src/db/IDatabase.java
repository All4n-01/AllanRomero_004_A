package db;

public interface IDatabase {
    public String DRIVER = "com.mysql.jdbc.Driver";
    public String HOST = "localhost";
    public String PORT = "3306";
    public String DATABASE = "employeedb";
    public String OPCIONES = "?charSet=LATIN1";
    public String JDBC = "jdbc:mysql://";
    public String USERNAME = "root";
    public String PASSWORD ="";   
}
