package modelo;

public class Excepcion extends Exception {
    public Excepcion() {
        super();
    }

    public Excepcion(String message) {
        super(message);
    }   
}
